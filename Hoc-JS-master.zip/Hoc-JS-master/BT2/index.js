document.getElementById('demo1').innerHTML = 'Tai lieu hoc CSS'
document.getElementById('demo2').innerHTML = 'Tai lieu hoc MySQL'
document.getElementById('demo3').innerHTML = 'Tai lieu hoc PHP'