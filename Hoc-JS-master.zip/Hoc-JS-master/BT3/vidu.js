var a = 10
var b = 25
var c = a + b

document.write('c= ' + c)
var x=  100 + 200
document.write('x= ' + x)

var a = prompt("nhap chieu dai: ","0" )
var b = prompt("nhap chieu rong: ","0" )

alert("Dien tich la: " + a*b)